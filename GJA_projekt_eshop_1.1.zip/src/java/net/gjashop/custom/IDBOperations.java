package net.gjashop.custom;

import net.gjashop.dao.IDBOperationsBase;

// this class is only generated once. it can be customized and all changes
// will be preserved.
public interface IDBOperations extends IDBOperationsBase {
	
}

package net.gjashop.dao;

// this class is generated. any change will be overridden.
public class OngoingShutdownException extends RuntimeException {
	
	private static final long serialVersionUID = 997906627613716196L;
}

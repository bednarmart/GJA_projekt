package net.gjashop.dao;

import net.gjashop.custom.IDBOperations;

// this class is generated. any change will be overridden.
public interface ICommand {
	
	public void execute(IDBOperations operations);
}

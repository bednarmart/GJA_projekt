var context;

function init(path) {
    context = path;
}


